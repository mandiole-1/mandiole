#! /usr/bin/python
# -*- coding:utf-8 -*-

from flask import Flask, request, render_template, redirect, url_for, abort, flash, session, g
from flask import Blueprint

from controllers.admin_station import *
from controllers.admin_hotel import *
from controllers.admin_reservation import *
from controllers.admin_client import *
from controllers.admin_chambre import *
from controllers.fixtures_load import *

app = Flask(__name__)
app.secret_key = 'une cle(token) : grain de sel(any random string)'

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/')
def show_accueil():
    print('ok')
    return render_template('admin/layout.html')



app.register_blueprint(admin_station)
app.register_blueprint(admin_hotel)
app.register_blueprint(admin_client)
app.register_blueprint(admin_chambre)
app.register_blueprint(admin_reservation)
app.register_blueprint(fixtures_load)

if __name__ == '__main__':
    app.run()

