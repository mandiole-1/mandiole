DROP TABLE IF EXISTS RESERVATION,CHAMBRE,HOTEL,CLIENT,STATION;


CREATE TABLE IF NOT EXISTS STATION(
   idStation INT Auto_Increment,
   nomStation VARCHAR(50),
   altitude INT,
   region VARCHAR(50),
   PRIMARY KEY(idStation)
);

CREATE TABLE IF NOT EXISTS CLIENT(
   IdClient INT AUTO_INCREMENT,
   nomClient VARCHAR(50),
   adresse VARCHAR(50),
   telephone VARCHAR(50),
   PRIMARY KEY(IdClient)
);

CREATE TABLE IF NOT EXISTS HOTEL(
   IdHotel INT AUTO_INCREMENT,
   nomHotel VARCHAR(50),
   categorie VARCHAR(50),
   station_id INT NOT NULL,
   photo varchar(50),
   PRIMARY KEY(IdHotel),
   FOREIGN KEY(station_id) REFERENCES STATION(idStation)
);

CREATE TABLE IF NOT EXISTS CHAMBRE(
   numChambre INT,
   nbLits INT,
   prixLocation DECIMAL(6,2),
   fraisService DECIMAL(7,2),
   disponible int,
   IdHotel INT NOT NULL,
   PRIMARY KEY(numChambre,IdHotel),
   FOREIGN KEY(IdHotel) REFERENCES HOTEL(IdHotel)
);

CREATE TABLE IF NOT EXISTS RESERVATION(
   IdClient INT,
   idHotel INT,
   chambre_num INT NOT NULL ,
   dateFin DATE,
   dateDebut DATE,
   nbPersonne INT,
   acompte DECIMAL(8,2),
   paiementSolde DECIMAL(8,2),
   remise DECIMAL(8,2),
   PRIMARY KEY(chambre_num, IdClient,dateDebut),
   CONSTRAINT test
   FOREIGN KEY(chambre_num)  REFERENCES CHAMBRE(numChambre),
   FOREIGN KEY(IdClient) REFERENCES CLIENT(IdClient),
   FOREIGN KEY (idHotel) REFERENCES  HOTEL(IdHotel)
);


INSERT INTO STATION(idStation,nomStation,altitude,region) VALUES
                          (1, 'Metabief', 1512, 'Jura'),
                          (2, 'Courchevel', 1820, 'Haute-Savoie'),
                          (3, 'Meribel', 1920, 'Haute-Savoie'),
                          (4, 'Chapelle-des-bois',1100, 'Jura'),
                          (5, 'le ballon d alsace',1100, 'Tre de Belfort');


INSERT INTO HOTEL(idHotel,nomHotel,station_id, categorie, photo) VALUES
                        (22, 'Douce Brise', 1, 'deux étoiles', 'hotel_jura3.png'),
                        (20, 'Les marmottes', 1, 'trois étoiles', ''),
                        (16, 'Bellevue', 2, 'deux étoiles', 'hotel_alpes1.png'),
                        (10, 'Neige Blanche', 2, 'trois étoiles', 'hotel_alpes1.png'),
                        (4, 'Le Savoy Méribel', 3, 'deux étoiles', 'hotel_alpes2.png'),
                        (5, 'Le Lac Bleu', 3, 'deux étoiles', 'hotel_alpes3.png'),
                        (30, 'au jura', 4, 'deux étoiles', 'hotel_jura1.png'),
                        (31, 'source du herisson', 4, 'deux étoiles', 'hotel_jura2.png');

INSERT INTO CHAMBRE(idHotel,numChambre,nbLits, prixLocation,fraisService,disponible) VALUES
                          (22, 1, 2, 75,9,1),
                          (22, 2, 1, 50,8,1),
                          (22, 3, 3, 100,3,1),
                          (22, 4, 3, 100,3,0),
                          (20, 1, 2, 150,7,1),
                          (20, 2, 1, 200,15,1),
                          (20, 3, 3, 250,0,1),
                          (16, 1, 2, 75,1,1),
                          (16, 2, 1, 50,0,1),
                          (16, 3, 3, 100,8,1),
                          (10, 1, 2, 150,6,1),
                          (10, 2, 3, 250,4,1),
                          (10, 3, 3, 250,5,1),
                          (4, 1, 2, 150,3,1),
                          (4, 2, 1, 100,1,1),
                          (5, 1, 3, 120,2,1),
                          (30, 1, 3, 250,4,1),
                          (30, 2, 2, 150,5,1),
                          (30, 3, 2, 150,5,0),
                          (30, 4, 2, 150,5,0),
                          (31, 1, 1, 100,0,1),
                          (31, 2, 3, 120,5,1);

INSERT INTO CLIENT(idClient,nomClient, adresse, telephone) VALUES
                        (1, 'Dupont Paul', '8 rue du jardin BELFORT', '0602030405'),
                         (2, 'Lang Coralie', '83 Avenue Millies Lacroix TOULOUSE', '0661521923'),
                         (3, 'Durand Jacques', '11 rue de la lavande AVIGNON', '0684623597'),
                         (4, 'Martin Thomas', '14 rue du rocher PARIS', '0612457896'),
                         (5, 'Michel Pascal', '11 rue de la lavande AVIGNON', '0684623597'),
                         (6, 'Nadeau Alexandrin', '15 rue de la Mare aux Carats MONTROUGE', '0631743559'),
                         (7, 'Chatigny Arthur', '82 Place Charles de Gaulle VILLEMOMBLE ', '0643520365');


INSERT INTO RESERVATION(idClient,idHotel, chambre_num, dateDebut,dateFin, nbPersonne,acompte,paiementSolde,remise) VALUES
                              (1, 22, 1, '2022-01-16', '2022-01-24', 1,58,0,0),
                              (2, 22, 2, '2022-01-14', '2022-01-18', 1,48,0,0),
                              (3, 16, 2, '2017-01-10', '2017-01-22', 1,95,0,0),
                              (4, 16, 3, '2017-02-10', '2017-02-20', 3,58,0,0),
                              (5, 10, 3, '2017-02-05', '2017-02-20', 3,63,0,0),
                              (6, 4, 1, '2017-02-10', '2017-02-18', 2,15,0,0),
                              (7, 5, 1, '2017-02-10', '2017-02-18', 3,87,0,0),
                              (2, 4, 2, '2016-12-10', '2016-12-20', 1,52,0,0),
                              (2, 4, 1, '2016-12-10', '2016-12-20', 1,50,0,0),
                              (7, 30, 1, '2018-02-10', '2018-02-18', 3,15,0,0),
                              (2, 30, 2, '2021-12-10', '2021-12-20', 1,18,0,0),
                              (2, 31, 2, '2022-12-10', '2022-12-20', 1,19,0,0);




