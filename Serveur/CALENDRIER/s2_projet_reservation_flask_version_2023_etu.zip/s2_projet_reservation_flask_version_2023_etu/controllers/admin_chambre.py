#! /usr/bin/python
# -*- coding:utf-8 -*-
from flask import Blueprint
from flask import Flask, request, render_template, redirect, url_for, abort, flash, session, g

from flask import *
import re
import datetime

import models.dao_hotel as mHotel
import models.dao_chambre as mChambre
from connexion_db import get_db

admin_chambre = Blueprint('admin_chambre', __name__,
                        template_folder='templates')

@admin_chambre.route('/admin/chambre/show')
def show_chambre():
    idHotel=request.args.get('idHotel', '')


    chambres = mChambre.getAllChambresInHotel(idHotel)
    hotel = mHotel.getHotel(idHotel)
    return render_template('admin/chambre/show_chambres.html', chambres=chambres, hotel=hotel)

@admin_chambre.route('/admin/chambre/add', methods=['GET'])
def add_chambre():
    idHotel = request.args.get('idHotel', '')
    hotel = mHotel.getHotel(idHotel)
    return render_template('admin/chambre/add_chambre.html', donnees2=hotel, donnees={'idHotel': idHotel}, erreurs=[])

@admin_chambre.route('/admin/chambre/add', methods=['POST'])
def valid_add_chambre():
    idHotel = request.form.get('idHotel', '')
    numChambre=request.form.get('numChambre', '')
    prixLocation = request.form.get('prixLocation', '')
    nbLits = request.form.get('nbLits', '')
    fraisService = request.form.get('fraisService', '')
    disponible = request.form.get('disponible','')

    if disponible:
        disponible = 1
    else:
        disponible = 0

    dto_data={'idHotel': idHotel, 'numChambre': numChambre, 'prixLocation': prixLocation, 'nbLits': nbLits,'fraisService':fraisService, 'disponible':disponible}
    valid, errors, dto_data = validator_chambre(dto_data)

    if valid:
        mChambre.insertChambre(int(numChambre), int(idHotel), int(nbLits), float(prixLocation), float(fraisService),disponible)
        message = u'chambre ajouté , hotel :'+str(idHotel)
        flash(message)
        return redirect('/admin/chambre/show?idHotel='+str(idHotel))

    hotel = mHotel.getHotel(int(idHotel))
    return render_template('admin/chambre/add_chambre.html', donnees2=hotel,
                           donnees=dto_data, erreurs=errors)

@admin_chambre.route('/admin/chambre/delete', methods=['GET'])
def delete_chambre():
    idHotel = request.args.get('idHotel', '')
    numChambre = request.args.get('numChambre', '')


    if not(numChambre and numChambre.isnumeric() and idHotel and idHotel.isnumeric()):
        abort(404,"erreur id")

    nbReservation = mChambre.getNbreservationOfChambre(int(idHotel),int(numChambre))

    if nbReservation == 0 :
        mChambre.deleteChambre(int(numChambre), int(idHotel))
        flash(u'chambre supprimée, chambre: ' + str(numChambre))
    else :
        flash(u'suppression impossible, il faut supprimer  : ' + str(nbReservation) + u' réservation(s) de cet chambre')
    return redirect('/admin/chambre/show?idHotel='+str(idHotel))

@admin_chambre.route('/admin/chambre/edit', methods=['GET'])
def edit_chambre():
    idHotel = request.args.get('idHotel', '')
    numChambre = request.args.get('numChambre', '')

    if not(numChambre and numChambre.isnumeric() and idHotel and idHotel.isnumeric()):
        abort(404,"erreur id")

    hotel = mHotel.getHotel(int(idHotel))
    chambre = mChambre.getChambreInHotel(int(idHotel),int(numChambre))

    return render_template('admin/chambre/edit_chambre.html', donnees=chambre, donnees2=hotel, erreurs=[])

@admin_chambre.route('/admin/chambre/edit', methods=['POST'])
def valid_edit_chambre():
    idHotel = request.form.get('idHotel', '')
    numChambre=request.form.get('numChambre', '')
    prixLocation = request.form.get('prixLocation', '')
    nbLits = request.form.get('nbLits', '')
    fraisService = request.form.get('fraisService', '')
    print("hotel : " + idHotel)
    dto_data={'idHotel': idHotel, 'prixLocation': prixLocation, 'nbLits': nbLits,'fraisService':fraisService}
    valid, errors, dto_data = validator_chambre(dto_data)
    print(valid,errors,dto_data)
    if valid:
        mChambre.updateChambre(numChambre, idHotel, nbLits, prixLocation, fraisService)
        flash(u' chambre modifié, numéro: ' + numChambre )
        return redirect('/admin/chambre/show?idHotel='+idHotel)

    hotel = mHotel.getHotel(int(idHotel))
    return render_template('admin/chambre/edit_chambre.html', donnees=dto_data, donnees2=hotel, erreurs=errors)

def validator_chambre(data):
    valid = True
    errors = dict()

    if 'idHotel' in data.keys():
        if not data['idHotel'].isdecimal():
            errors['idHotel'] = 'type idHotel incorrect'
            valid = False


    if 'nbLits' in data.keys():
        if not data['nbLits'].isdecimal():
            errors['nbLits'] = 'type Nb Lits incorrect'
            valid = False


    if 'numChambre' in data.keys():
        if not data['numChambre'].isdecimal():
            errors['numChambre'] = 'type Numéro Chambre incorrect'
            valid = False
        elif mChambre.getChambreInHotel(int(data["idHotel"]),int(data["numChambre"])) != None:
            errors['numChambre'] = 'Chambre déja existante'
            valid = False


    try:
        float(data['prixLocation'])
    except ValueError:
        flash("Prix n'est pas valide")
        errors['prixLocation'] = "le Prix n'est pas valide"
        valid = False

    try:
        float(data['fraisService'])
    except ValueError:
        flash("Frais Service n'est pas valide")
        errors['fraisService'] = "le frais de services n'est pas valide"
        valid = False

    return (valid, errors, data)
