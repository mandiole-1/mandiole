#! /usr/bin/python
# -*- coding:utf-8 -*-
import re
from flask import *
import datetime

import models.dao_client
from connexion_db import get_db

admin_client = Blueprint('admin_client', __name__,
                        template_folder='templates')

@admin_client.route('/admin/client/show')
def show_client():
    mycursor = get_db().cursor()
    clients = models.dao_client.getAllClients()
    return render_template('admin/client/show_clients.html', clients=clients)

@admin_client.route('/admin/client/add', methods=['GET'])
def add_client():
    erreurs=[]
    donnees=[]
    return render_template('admin/client/add_client.html', erreurs=erreurs, donnees=donnees)

@admin_client.route('/admin/client/add', methods=['POST'])
def valid_add_client():
    nom = request.form.get('nom', '')
    adresse = request.form.get('adresse', '')
    #datePaiement = request.form.get('datePaiement', '')
    telephone = request.form.get('telephone', '')

    dto_data={'nom': nom, 'adresse': adresse}# 'datePaiement': datePaiement
    valid, errors, dto_data = validator_client(dto_data)
    if valid:
        #datePaiement=dto_data['datePaiement_us']
        tuple_insert = (nom,adresse,telephone)
        mycursor = get_db().cursor()
        ''' SELECT 'requete2_2' FROM DUAL '''
        models.dao_client.client_insert(nom,adresse,telephone)
        message = u'client ajouté , libellé :'+nom
        flash(message)
        return redirect('/admin/client/show')
    return render_template('admin/client/add_client.html', erreurs=errors, donnees=dto_data)

@admin_client.route('/admin/client/delete', methods=['GET'])
def delete_client():
    mycursor = get_db().cursor()
    id_client = request.args.get('id', '')
    if not(id_client and id_client.isnumeric()):
        abort("404","erreur id client")
    ''' SELECT 'requete2_6' FROM DUAL '''

    nb_reservation=models.dao_client.find_client_nbReservation(id_client)
    if nb_reservation == 0 :
        ''' SELECT 'requete2_3' FROM DUAL '''
        models.dao_client.client_delete(id_client)
        flash(u'client supprimé, id: ' + id_client)
    else :
        flash(u'suppression impossible, il faut supprimer  : ' + str(nb_reservation) + u' réservation(s) de ce client')
    return redirect('/admin/client/show')

@admin_client.route('/admin/client/edit', methods=['GET'])
def edit_client():
    id_client = request.args.get('id', '')
    ''' SELECT 'requete2_4' FROM DUAL '''
    client = models.dao_client.find_one_client(id_client)
    """erreurs=[]
    if client['date_paiement']:
        client['datePaiement']=client['date_paiement'].strftime("%d/%m/%Y")
    
    """
    erreurs = []
    return render_template('admin/client/edit_client.html', donnees=client, erreurs=erreurs)

@admin_client.route('/admin/client/edit', methods=['POST'])
def valid_edit_client():
    id = request.form.get('id', '')
    nom = request.form.get('nom', '')
    adresse = request.form.get('adresse', '')
    telephone = request.form.get('telephone')
    #datePaiement = request.form.get('datePaiement', '')
    dto_data={'nom': nom, 'adresse': adresse, 'id':id}#, 'datePaiement': datePaiement
    valid, errors, dto_data = validator_client(dto_data)
    if valid:
        #datePaiement=dto_data['datePaiement_us']
        tuple_update = (nom,adresse,telephone,id)#,datePaiement
        mycursor = get_db().cursor()
        ''' SELECT 'requete2_5' FROM DUAL '''

        models.dao_client.client_update(nom,adresse,telephone,id)
        flash(u'client modifié, id: ' + id + " nom : " + nom)
        return redirect('/admin/client/show')
    return render_template('admin/client/edit_client.html', erreurs=errors, donnees=dto_data)

def validator_client(data):
    valid = True
    errors = dict()

    if 'id' in data.keys():
        if not data['id'].isdecimal():
           errors['id'] = 'type id incorrect'
           valid= False

    if not re.match(r'\w{2,}', data['nom']):
        errors['nom'] = "Le Nom doit avoir au moins deux caractères"
        valid = False
    """
    try:
        datetime.datetime.strptime(data['datePaiement'], '%d/%m/%Y')
    except ValueError:
        errors['datePaiement'] = "Date n'est pas valide format:%d/%m/%Y"
        valid = False
    else:
        data['datePaiement_us'] = datetime.datetime.strptime(data['datePaiement'], "%d/%m/%Y").strftime("%Y-%m-%d")
    """
    return (valid, errors, data)






