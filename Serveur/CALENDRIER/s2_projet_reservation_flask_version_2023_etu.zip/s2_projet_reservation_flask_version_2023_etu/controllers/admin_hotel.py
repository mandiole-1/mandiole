#! /usr/bin/python
# -*- coding:utf-8 -*-
import re
from flask import *
import datetime

import os

import models.dao_station
from connexion_db import get_db

admin_hotel = Blueprint('admin_hotel', __name__,
                        template_folder='templates')

@admin_hotel.route('/admin/hotel/show')
def show_hotel():
    mycursor = get_db().cursor()
    ''' SELECT 'requete3_1' FROM DUAL '''
    sql ='''SELECT HOTEL.idHotel,photo,nomHotel,categorie,nomStation ,COUNT(CH1.numChambre) AS nbChambresDisponible,COUNT(CH2.numChambre)AS nbChambresNonDisponible
     FROM HOTEL
     INNER JOIN STATION ON STATION.idStation = HOTEL.station_id
     LEFT JOIN CHAMBRE AS CH1 ON CH1.IdHotel = HOTEL.IdHotel 
     LEFT JOIN CHAMBRE AS CH2 ON CH1.IdHotel = CH2.IdHotel AND CH1.numChambre =CH2.numChambre AND CH1.disponible=0
     GROUP BY HOTEL.idHotel,nomHotel,nomStation 
     ORDER BY nomHotel,nomStation;'''
    mycursor.execute(sql)


    hotels = mycursor.fetchall()
    return render_template('admin/hotel/show_hotel.html', hotels=hotels)

@admin_hotel.route('/admin/hotel/add', methods=['GET'])
def add_hotel():
    ''' SELECT 'requete3_6' FROM DUAL '''

    station = models.dao_station.find_stations_dropdown()
    return render_template('admin/hotel/add_hotel.html', stations=station, donnees=[], erreurs=[])

@admin_hotel.route('/admin/hotel/add', methods=['POST'])
def valid_add_hotel():
    mycursor = get_db().cursor()
    nom = request.form.get('nom', '')
    categorie = request.form.get('categorie', '')
    station_id = request.form.get('idStation','')
    photo = request.form.get('photo', '')

    dto_data={'nom': nom, 'photo': photo, 'categorie': categorie, 'station_id': station_id}
    valid, errors, dto_data = validator_hotel(dto_data)
    if valid:
        tuple_insert = (nom,categorie,station_id,photo)
        ''' SELECT 'requete3_2' FROM DUAL '''
        sql = '''INSERT INTO HOTEL(IdHotel,nomHotel,categorie,station_id,photo) VALUES(null,%s,%s,%s,%s);'''
        mycursor.execute(sql, tuple_insert)
        get_db().commit()
        print(u'hotel ajouté , nom: ', nom, ' - categorie:', categorie,' - station_id:' ,station_id , ' - photo:', photo)
        message = u'hotel ajouté , nom:'+nom + '- categorie:', categorie +'- station_id:' +station_id + ' - photo:' + photo
        flash(message)
        return redirect('/admin/hotel/show')


    stations = models.dao_station.find_stations_dropdown();
    return render_template('admin/hotel/add_hotel.html', stations=stations, erreurs=errors, donnees=dto_data)

@admin_hotel.route('/admin/hotel/delete', methods=['GET'])
def delete_hotel():
    mycursor = get_db().cursor()
    id = request.args.get('id', '')
    if not(id and id.isnumeric()):
        abort("404","erreur id hotel")
    tuple_delete = (id,)

    chambres= 0
    ''' SELECT 'requete3_7' FROM DUAL '''
    sql =  '''SELECT COUNT(DISTINCT numChambre) AS nb FROM CHAMBRE  WHERE IdHotel =%s'''
    mycursor.execute(sql, tuple_delete)
    res_nb_chambres = mycursor.fetchone()
    if 'nb' in res_nb_chambres.keys():
        chambres=res_nb_chambres['nb']
    if chambres == 0 :
        ''' SELECT 'requete3_3' FROM DUAL '''
        sql = '''DELETE FROM HOTEL WHERE IdHotel=%s;'''

        mycursor.execute(sql, tuple_delete)
        get_db().commit()
        flash(u'hotel supprimée, id: ' + id)
    else :
        flash(u'suppression impossible, il faut supprimer  : ' + str(chambres) + u' chambre(s) de cet hotel')
    return redirect('/admin/hotel/show')

@admin_hotel.route('/admin/hotel/edit', methods=['GET'])
def edit_hotel():
    id = request.args.get('id', '')
    mycursor = get_db().cursor()
    ''' SELECT 'requete3_4' FROM DUAL '''
    sql = '''SELECT idhotel, nomhotel as nomHotel, categorie,station_id AS idStation, photo FROM HOTEL WHERE IdHotel= %s'''
    mycursor.execute(sql, (id,))
    hotel = mycursor.fetchone()
    ''' SELECT 'requete3_6' FROM DUAL '''
    sql ='''SELECT idStation,nomStation FROM STATION'''
    mycursor.execute(sql)
    stations = mycursor.fetchall()
    return render_template('admin/hotel/edit_hotel.html', donnees=hotel, stations=stations, erreurs=[])

@admin_hotel.route('/admin/hotel/edit', methods=['POST'])
def valid_edit_hotel():
    mycursor = get_db().cursor()
    id = request.form.get('id', '')
    mycursor = get_db().cursor()
    nom = request.form.get('nom', '')
    categorie = request.form.get('categorie', '')
    station_id = request.form.get('idStation', '')
    photo = request.form.get('photo', '')

    dto_data = {'nomHotel': nom, 'photo': photo, 'categorie': categorie, 'idStation': station_id, 'id': id}
    valid, errors, dto_data = validator_hotel(dto_data)
    if valid:
        tuple_update = (nom,categorie,photo,station_id,id)
        print(tuple_update)
        ''' SELECT 'requete3_5' FROM DUAL '''
        sql = '''UPDATE HOTEL SET nomHotel =%s,categorie=%s,photo=%s,station_id=%s WHERE IdHotel =%s;'''
        mycursor.execute(sql, tuple_update)
        get_db().commit()
        print(u'hotel modifié , nom: ', nom, ' - categorie:', categorie, ' - station_id:', station_id, ' - photo:',photo,'id', id)
        message = u'hotel modifié , nom:' + nom + '- categorie:', categorie + '- station_id:' + station_id + ' - photo:' + photo + 'id'+ id

        flash(message)
        return redirect('/admin/hotel/show')
    stations = models.dao_station.find_stations_dropdown()
    return render_template('admin/hotel/edit_hotel.html', stations=stations, erreurs=errors, donnees=dto_data)


def validator_hotel(data):
    mycursor = get_db().cursor()
    valid = True
    errors = dict()

    if 'id' in data.keys():
        if not data['id'].isdecimal():
           errors['id'] = 'type id incorrect'
           valid= False
    sql = ''' SELECT 'requete1_4' FROM DUAL '''
    station = models.dao_station.find_one_station(data['idStation'])
    if not station:
        flash("station n'existe pas")
        errors['station_id'] = "Saisir une station"
        valid = False
    else :
        data['idStation']=int(data['idStation'])

    if not re.match(r'\w{2,}', data['nomHotel']):
        flash('nom doit avoir au moins deux caractères')
        errors['nomHotel'] = "Le nom doit avoir au moins deux caractères"
        valid = False
    if data['photo']:
        photo_path = os.path.join(current_app.root_path,
                                  'static', 'assets', 'images', data['photo'])

        if not os.path.isfile(photo_path) and photo_path!="":
            flash(f"Photo n'existe pas: { photo_path }")
            errors['photo'] = f"la Photo n'existe pas: { photo_path }"
            valid = False
    return (valid, errors, data)
