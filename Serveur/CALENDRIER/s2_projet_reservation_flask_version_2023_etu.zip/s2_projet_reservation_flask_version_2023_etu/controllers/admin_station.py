#! /usr/bin/python
# -*- coding:utf-8 -*-
import re
from flask import *

import models.dao_station as mStation
from connexion_db import get_db

admin_station = Blueprint('admin_station', __name__,
                        template_folder='templates')

@admin_station.route('/admin/station/show')
def show_station():
    mycursor = get_db().cursor()
    ''' SELECT 'requete1_1' FROM DUAL '''
    stations = mStation.getAllStations()
    print(stations)
    return render_template('admin/station/show_stations.html', stations=stations)

@admin_station.route('/admin/station/add', methods=['GET'])
def add_station():
    return render_template('admin/station/add_station.html',erreurs=[],donnees=[])

@admin_station.route('/admin/station/add', methods=['POST'])
def valid_add_station():
    mycursor = get_db().cursor()
    nom = request.form.get('nom', '')
    altitude = request.form.get('altitude', '')
    region = request.form.get('region','')

    dto_data={'nomStation': nom, 'region':region,'altitude':altitude}
    valid, errors = validator_station(dto_data)

    tuple_insert = (nom,altitude,region)
    if valid:
        ''' SELECT 'requete1_2' FROM DUAL '''

        #DAO OK
        mStation.station_insert(nom,altitude,region)

        message = u'station ajouté , nom :'+nom
        flash(u'station ajoutée , nom :'+nom, 'success radius'),
        return redirect('/admin/station/show')
    return render_template('admin/station/add_station.html', erreurs=errors, donnees=dto_data)

@admin_station.route('/admin/station/delete', methods=['GET'])
def delete_station():
    mycursor = get_db().cursor()
    id_station = request.args.get('id', '')
    if not(id_station and id_station.isnumeric()):
        abort(404,"erreur id station")
    nb_hotels = 0
    ''' SELECT 'requete1_6' FROM DUAL '''

    nb_hotels = mStation.find_station_nb_hotels(id_station)
    # if 'nbHotels' in res_nb_oeuvres.keys():
    #     nbHotels=res_nb_oeuvres['nb_oeuvres']
    print(nb_hotels)
    if nb_hotels == 0 :
        ''' SELECT 'requete1_3' FROM DUAL '''

        # DAO OK
        mStation.station_delete(id_station)

        flash(u'station supprimé, id: ' + id_station)
        flash(u'station supprimée, id: ' + id_station, 'success radius')
    else :
        flash(u'suppression impossible, il faut supprimer  : ' + str(nb_hotels) + u' hotel(s) de cette station', 'warning radius')
    return redirect('/admin/station/show')

@admin_station.route('/admin/station/edit', methods=['GET'])
def edit_station():
    id = request.args.get('id', '')
    mycursor = get_db().cursor()
    ''' SELECT 'requete1_4' FROM DUAL '''

    station = mStation.find_one_station(id)
    erreurs=[]
    return render_template('admin/station/edit_station.html', donnees=station, erreurs=[])

@admin_station.route('/admin/station/edit', methods=['POST'])
def valid_edit_station():
    nom = request.form.get('nom', '')
    region = request.form.get('region', '')
    altitude = request.form.get('altitude', '')
    id = request.form.get('id', '')
    dto_data={'nomStation': nom, 'altitude':altitude, 'id': id,'region':region}
    valid, errors = validator_station(dto_data)
    print(valid,errors)
    if valid:
        tuple_update = (nom,altitude,region,id)
        mycursor = get_db().cursor()
        ''' SELECT 'requete1_5' FROM DUAL '''

        # DAO OK
        mStation.station_update(nom,altitude,region,id)

        flash(u'station modifiée, id: ' + id + " nom : " + nom, 'success radius')
        return redirect('/admin/station/show')
    return render_template('admin/station/edit_station.html', donnees=dto_data, erreurs=errors)

def validator_station(data):
    valid = True
    errors = dict()
    if not re.match(r'\w{2,}', data['nomStation']):
        # flash('Nom doit avoir au moins deux caractères')
        errors['nomStation'] = 'Nom doit avoir au moins deux caractères'
        valid = False
    if 'id' in data.keys():
        if not data['id'].isdecimal():
           errors['id'] = 'type id incorrect'
           valid= False

    if 'altitude' in data.keys():
        if not data['altitude'].isdecimal():
           errors['altitude'] = 'type altitude incorrect'
           valid= False
    return (valid, errors)





