
from connexion_db import get_db
from flask import *

def getAllClients():
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = ''' SELECT CLIENT.IdClient as idClient,nomClient,adresse ,telephone, COUNT(RESERVATION.chambre_num) AS nbReservations 
        ,COUNT(R2.idClient) AS nbReservations_moins2ans
             FROM CLIENT 
             JOIN RESERVATION  ON CLIENT.IdClient=RESERVATION.idClient
             LEFT JOIN RESERVATION R2 ON RESERVATION.idClient=R2.idClient AND (CURRENT_DATE()<DATE_ADD(R2.dateDebut, INTERVAL 2 YEAR) )
             GROUP BY CLIENT.IdClient; '''
        cursor.execute(sql)
        return cursor.fetchall()
    except ValueError:
        abort(400,'erreur requete 2_1')

def find_client_nbReservation(id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = """ SELECT COUNT(idCLient) AS compteur FROM RESERVATION WHERE idClient= %s;"""
        cursor.execute(sql, (id))
        res_nb_reservation = cursor.fetchone()
        if 'compteur' in res_nb_reservation.keys():
            nb_reservation=res_nb_reservation['compteur']
            return nb_reservation
    except ValueError:
        abort(400,'erreur requete 2_6')

def find_one_client(id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = '''SELECT IdCLient as idClient,nomClient,adresse,telephone FROM CLIENT WHERE IdClient= %s;'''
        cursor.execute(sql, (id))
        return cursor.fetchone()
    except ValueError:
        abort(400,'erreur requete 2_4')


def client_insert(nom,adresse,telephone):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = '''INSERT INTO CLIENT(IdCLient,nomClient ,adresse,telephone) VALUES(null,%s,%s,%s);'''
        cursor.execute(sql, (nom,adresse,telephone))
        connection.commit()
    except ValueError:
        abort(400,'erreur requete 1_2')

def client_update(nom,adresse,telephone,id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = '''UPDATE CLIENT SET nomClient = %s, adresse=%s , telephone = %s WHERE IdClient = %s;'''
        cursor.execute(sql, (nom,adresse,telephone,id))
        connection.commit()
    except ValueError:
        abort(400,'erreur requete 2_5')

def client_delete(id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql =  """DELETE FROM CLIENT WHERE IdCLient = %s;"""
        cursor.execute(sql, (id))
        connection.commit()
    except ValueError:
        abort(400,'erreur requete 2_3')
