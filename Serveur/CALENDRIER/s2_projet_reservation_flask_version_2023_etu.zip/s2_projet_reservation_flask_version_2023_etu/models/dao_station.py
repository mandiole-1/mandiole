from connexion_db import get_db
from flask import *

def getAllStations():
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = ''' SELECT idStation,nomStation,altitude,region, COUNT(idHotel) AS nbHotels FROM STATION LEFT JOIN HOTEL ON station_id = idStation GROUP BY idStation, nomStation, altitude, region;'''
        cursor.execute(sql)
        return cursor.fetchall()
    except ValueError:
        abort(400,'erreur requete 1_1')

def find_station_nb_hotels(id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql =""" SELECT COUNT(idHotel) AS compteur FROM HOTEL WHERE station_id = %s;"""
        cursor.execute(sql, (id))
        res_nb_oeuvres = cursor.fetchone()
        if 'nb_oeuvres' in res_nb_oeuvres.keys():
            nb_oeuvres=res_nb_oeuvres['nb_oeuvres']
            return nb_oeuvres
    except ValueError:
        abort(400,'erreur requete 1_6')

def find_one_station(id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql =  '''SELECT * FROM STATION WHERE idStation = %s;'''
        cursor.execute(sql, (id))
        return cursor.fetchone()
    except ValueError:
        abort(400,'erreur requete 1_4')

def find_stations_dropdown():
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = """SELECT idStation,nomStation FROM STATION;"""
        cursor.execute(sql)
        return cursor.fetchall()
    except ValueError:
        abort(400,'erreur requete "_6')

def station_insert(nom,altitude,region):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = '''INSERT INTO STATION(idStation,nomStation,altitude,region) VALUES (null,%s,%s,%s)'''
        cursor.execute(sql, (nom, altitude,region))
        connection.commit()
    except ValueError:
        abort(400,'erreur requete 1_2')



def station_update(nom,altitude,region,id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = '''UPDATE STATION SET nomStation = %s, altitude=%s , region = %s WHERE idStation = %s;'''
        cursor.execute(sql, (nom,altitude,region,id))
        connection.commit()
    except ValueError:
        abort(400,'erreur requete 1_5')

def station_delete(id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = """DELETE FROM STATION WHERE idStation = %s;"""
        cursor.execute(sql, (id))
        connection.commit()
    except ValueError:
        abort(400,'erreur requete 1_3')








