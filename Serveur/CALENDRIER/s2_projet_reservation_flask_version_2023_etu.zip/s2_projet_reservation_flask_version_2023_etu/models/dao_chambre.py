
from connexion_db import get_db
from flask import *

def getChambreInHotel(idHotel,idChambre):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = ''' SELECT 'requete4_1' FROM DUAL '''
        sql = ''' 
        SELECT DISTINCT CH2.*,
                   IF(CH1.numChambre is not null, 'Indisponible','Disponible') as disponibilite
                   FROM HOTEL
                    INNER JOIN CHAMBRE CH2 ON CH2.idHotel=HOTEL.idHotel
                    LEFT JOIN CHAMBRE CH1 ON CH1.idHotel=HOTEL.idHotel  AND (CH1.numChambre,CH1.idHotel) in
                      (SELECT CH1.numChambre,idHotel
                      FROM RESERVATION
                      WHERE dateDebut <= CURDATE() AND dateFin >= CURDATE())
             WHERE CH2.idHotel=%s AND CH2.numChambre=%s
        '''
        cursor.execute(sql,(idHotel,idChambre))
        return cursor.fetchone()
    except ValueError:
        abort(400,'erreur requete 4_1')

def getAllChambresInHotel(idHotel):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = '''
        SELECT DISTINCT CH2.*,
                   IF(CH1.numChambre is not null, 'Indisponible','Disponible') as disponibilite
                   FROM HOTEL
                    INNER JOIN CHAMBRE CH2 ON CH2.idHotel=HOTEL.idHotel
                    LEFT JOIN CHAMBRE CH1 ON CH1.idHotel=HOTEL.idHotel  AND (CH1.numChambre,CH1.idHotel) in
                      (SELECT CH1.numChambre,idHotel -- !!!!!!!!!!!!!!!!   numChambre is ambigous => CH1.numChambre
                      FROM RESERVATION
                      WHERE dateDebut <= CURDATE() AND dateFin >= CURDATE())
         WHERE CH2.idHotel=%s
         '''
        cursor.execute(sql,(idHotel))
        return cursor.fetchall()
    except ValueError:
        abort(400,'erreur requete 4_2')

def getNbreservationOfChambre(idHotel,idChambre):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = ''' SELECT COUNT(*) FROM RESERVATION WHERE chambre_num=%s AND idHotel=%s '''
        cursor.execute(sql, (idChambre,idHotel))
        res_nb = cursor.fetchone()
        if 'nb' in res_nb.keys():
            return res_nb['nb']
        return 0
    except ValueError:
        abort(400,'erreur requete 4_7')

'''
def find_edit_one_exemplaire(id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = ' SELECT 'requete4_11' FROM DUAL '
        cursor.execute(sql, (id))
        return cursor.fetchone()
    except ValueError:
        abort(400,'erreur requete 4_11')
'''

'''
def find_id_oeuvre_exemplaire(id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = ' SELECT 'requete4_9' FROM DUAL '
        cursor.execute(sql, (id))
        oeuvre = cursor.fetchone()
        oeuvre_id=str(oeuvre['oeuvre_id'])
        return oeuvre_id
    except ValueError:
        abort(400,'erreur requete 4_9')
'''

'''
def find_add_exemplaire_info_oeuvre(id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = ' SELECT 'requete4_3' FROM DUAL '
        cursor.execute(sql, (id))
        oeuvre = cursor.fetchone()
        return oeuvre
    except ValueError:
        abort(400,'erreur requete 4_3')
'''

'''
def find_edit_details_oeuvre_id_exemplaire(id):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = ' SELECT 'requete4_10' FROM DUAL '
        cursor.execute(sql, (id))
        exemplaire = cursor.fetchone()
        return exemplaire
    except ValueError:
        abort(400,'erreur requete 4_10')
'''


def insertChambre(numChambre,idHotel,nbLits,prixLocation,fraisService,disponible):
    connection = get_db()
    print(disponible)
    try:
        cursor=connection.cursor()
        sql = ''' INSERT INTO CHAMBRE (idHotel, numChambre, nbLits, prixLocation, fraisService,disponible) VALUES (%s,%s,%s,%s,%s,%s)'''
        cursor.execute(sql, (idHotel,numChambre,nbLits,prixLocation,fraisService,disponible)) # DISPONIBLE N'ETAIT PAS FAIT HTML,ADMIN ET DAO
        connection.commit()
    except ValueError:
        abort(400,'erreur requete 4_5')

def updateChambre(numChambre,idHotel,nbLits,prixLocation,fraisService):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = ''' UPDATE CHAMBRE SET nbLits=%s, prixLocation=%s, fraisService=%s WHERE numChambre=%s AND idHotel=%s '''
        cursor.execute(sql, (nbLits,prixLocation,fraisService, numChambre,idHotel))
        connection.commit()
    except ValueError:
        abort(400,'erreur requete 4_12')

def deleteChambre(numChambre,idHotel):
    connection = get_db()
    try:
        cursor=connection.cursor()
        sql = ''' DELETE FROM CHAMBRE WHERE numChambre=%s AND idHotel=%s'''
        cursor.execute(sql, (numChambre,idHotel))
        connection.commit()
    except ValueError:
        abort(400,'erreur requete 4_8')
